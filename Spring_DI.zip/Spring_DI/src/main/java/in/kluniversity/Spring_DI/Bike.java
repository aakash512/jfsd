package in.kluniversity.Spring_DI;

import org.springframework.stereotype.Component;

@Component
public class Bike {
	
	public void drive()
	{
		System.out.println("Driving a bike");
	}
}
