package in.kluniversity.Spring_DI;

public interface Manufacturer {

	String name();
}
