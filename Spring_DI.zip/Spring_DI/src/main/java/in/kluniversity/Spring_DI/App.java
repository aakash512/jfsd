package in.kluniversity.Spring_DI;
import org.springframework.context.*;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import java.lang.reflect.Type;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	 ApplicationContext factory = new AnnotationConfigApplicationContext(AnnotationConfig.class);
         Engine engine = factory.getBean(Engine.class);
         engine.model();
    }
}
