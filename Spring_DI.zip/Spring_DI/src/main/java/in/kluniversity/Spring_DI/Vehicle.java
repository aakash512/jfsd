package in.kluniversity.Spring_DI;

public interface Vehicle {
   void drive();
}
