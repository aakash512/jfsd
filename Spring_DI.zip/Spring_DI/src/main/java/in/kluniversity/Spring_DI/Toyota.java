package in.kluniversity.Spring_DI;

import org.springframework.stereotype.Component;

@Component
public class Toyota implements Manufacturer {

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "Toyota";
	}

}
